package com.hackerranker.arrays;

import org.junit.*;
import static org.junit.Assert.*;

public class ArrayQuestionsTest {
    @Test
    public void testFindMax() {
        assertEquals(9, ArrayQuestions.findMax(new int[]{1, 5, 3, 9, 2}));
    }

    @Test
    public void testReverseArray() {
        assertArrayEquals(new int[]{5, 4, 3, 2, 1}, ArrayQuestions.reverseArray(new int[]{1, 2, 3, 4, 5}));
    }

    @Test
    public void testSumOfEvenNumbers() {
        assertEquals(12, ArrayQuestions.sumOfEvenNumbers(new int[]{1, 2, 4, 6, 7}));
    }
}