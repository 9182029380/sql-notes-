package com.hackerranker.strings;

import org.junit.*;
import static org.junit.Assert.*;

public class StringQuestionsTest {
    @Test
    public void testIsPalindrome() {
        assertTrue(StringQuestions.isPalindrome("madam"));
        assertFalse(StringQuestions.isPalindrome("java"));
    }

    @Test
    public void testCountVowels() {
        assertEquals(5, StringQuestions.countVowels("education"));
    }

    @Test
    public void testReverseWords() {
        assertEquals("world hello", StringQuestions.reverseWords("hello world"));
    }
}