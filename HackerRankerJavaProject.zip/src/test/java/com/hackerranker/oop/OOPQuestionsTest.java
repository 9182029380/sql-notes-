package com.hackerranker.oop;

import org.junit.*;
import static org.junit.Assert.*;

public class OOPQuestionsTest {
    @Test
    public void testGetDogSpeech() {
        assertEquals("Woof", OOPQuestions.getDogSpeech());
    }

    @Test
    public void testIsInstanceOfAnimal() {
        assertTrue(OOPQuestions.isInstanceOfAnimal(new Dog()));
    }

    @Test
    public void testPolymorphicSpeak() {
        Animal a = new Dog();
        assertEquals("Woof", OOPQuestions.getPolymorphicSpeak(a));
    }
}