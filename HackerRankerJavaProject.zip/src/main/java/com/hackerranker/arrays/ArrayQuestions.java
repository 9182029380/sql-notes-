package com.hackerranker.arrays;

public class ArrayQuestions {
    public static int findMax(int[] arr) {
        return -1;
    }

    public static int[] reverseArray(int[] arr) {
        return null;
    }

    public static int sumOfEvenNumbers(int[] arr) {
        return -1;
    }
}