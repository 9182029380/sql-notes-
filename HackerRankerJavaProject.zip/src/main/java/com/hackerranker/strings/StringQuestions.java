package com.hackerranker.strings;

public class StringQuestions {
    public static boolean isPalindrome(String str) {
        return false;
    }

    public static int countVowels(String str) {
        return -1;
    }

    public static String reverseWords(String sentence) {
        return null;
    }
}