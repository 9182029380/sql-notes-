package com.hackerranker.oop;

class Animal {
    public String speak() {
        return "Animal";
    }
}

class Dog extends Animal {
    @Override
    public String speak() {
        return "Woof";
    }
}

public class OOPQuestions {
    public static String getDogSpeech() {
        return null;
    }

    public static boolean isInstanceOfAnimal(Object obj) {
        return false;
    }

    public static String getPolymorphicSpeak(Animal a) {
        return null;
    }
}